from xolpanel import *

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Password:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 3 Day •","3"),
Button.inline("• 7 Day •","7")],
[Button.inline("• 30 Day •","30"),
Button.inline("• 60 Day •","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		cmd = f'useradd -e `date -d "`{exp} days" +"%Y-%m-%d"` -s /bin/false -M `{user} && echo "`{pw}\n`{pw}" | passwd `{user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**			
**» Username         :** `{user.strip()}`
Password         :** `{pw.strip()}`
**» Expired          :** ``{later}`
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**» IP               :** `{IP}`
**» Host             :** `{DOMAIN}`
**» Host Slowdns     :** `{NS}`
**» Pub Key          :** `{PUB}`
**» Location         :** `{CITY}`"
**» Port OpenSSH     :** `443`, `80`, `22`
**» Port DNS         :** `443`, `53` ,`22`
**» Port Dropbear    :** `443`, `109`
**» Port Dropbear WS :** `443`, `109`
**» Port SSH WS      :** `80`
**» Port SSH SSL WS  :** `443`
**» Port SSL/TLS     :** `443`
**» Port OVPN WS SSL :** `443`
**» Port OVPN SSL    :** `443`
**» Port OVPN TCP    :* `443`, `1194`
**» Port OVPN UDP    :** `2200`
**» Proxy Squid      :** 3128
**» BadVPN UDP       :** `7100`, `7300`, `7300`
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**» Payload WS       :** `GET / HTTP/1.1[crlf]Host: `{DOMAIN}[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**» Payload WSS      :** `GET wss://[host]/ HTTP/1.1[crlf]Host: `{DOMAIN}[host_port][crlf]Upgrade: Websocket[crlf]Connection: Keep-Alive[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**» OpenVPN WS SSL   :** `https://`{DOMAIN}:`81`/"`{DOMAIN}-ws-ssl.ovpn`
**» OpenVPN SSL      :** `https://`{DOMAIN}`:81/`{DOMAIN}-ssl.ovpn`
**» OpenVPN TCP      :** `https://`{DOMAIN}:81/`{DOMAIN}-tcp.ovpn`
**» OpenVPN UDP      :** `https://`{DOMAIN}:81/`{DOMAIN}-udp.ovpn`
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**» Save Link Account: `https://`{DOMAIN}:81/ssh-`{user.strip()}`.txt`
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
**»  🤖@RizkiHdyt99**
**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**
"""
			inline = [
[Button.url("[ GitHub Repo ]","github.com/xolvaid/simplepanel"),
Button.url("[ Channel ]","t.me/XolPanel")]]
			await event.respond(msg,buttons=inline)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
